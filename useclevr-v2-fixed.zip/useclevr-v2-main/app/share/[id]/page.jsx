"use client";

export default function SharePage() {
  return (
    <div className="p-8">
      <h1 className="text-2xl font-bold">Shared Dataset</h1>
      <p className="text-gray-400">
        Share preview temporarily disabled.
      </p>
    </div>
  );
}
