"use client";

import { useEffect, useState } from "react";

// Components
import KpiCard from "@/components/KpiCard";
import SchemaInspector from "@/components/dataset/SchemaInspector";
import ChartSuggestions from "@/components/ChartSuggestions";

// Utils
import extractKpis from "@/utils/extractKpis";
import inspectSchema from "@/utils/inspectSchema";

export default function LiveInsightsPage() {
  const [dataset, setDataset] = useState([]);
  const [columns, setColumns] = useState([]);
  const [kpis, setKpis] = useState([]);
  const [schema, setSchema] = useState([]);
  const [chartBase64, setChartBase64] = useState("");
  const [question, setQuestion] = useState("");
  const [answer, setAnswer] = useState("");
  const [loading, setLoading] = useState(false);

  // Load dataset
  useEffect(() => {
    const raw = localStorage.getItem("useclevr_dataset");
    if (!raw) return;

    const parsed = JSON.parse(raw);
    setDataset(parsed);

    if (parsed.length > 0) {
      setColumns(Object.keys(parsed[0]));
    }

    // KPIs + Schema
    setKpis(extractKpis(parsed));
    setSchema(inspectSchema(parsed));
  }, []);

  // Ask AI
  async function askAI() {
    if (!question.trim()) return;

    setLoading(true);
    setAnswer("");

    try {
      const res = await fetch("/api/insights", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          question,
          dataset,
          kpis,
          schema,
          correlations: null, // bewusst deaktiviert (build-safe)
        }),
      });

      const data = await res.json();
      setAnswer(data.answer || "AI returned no response.");
    } catch (e) {
      setAnswer("Error: " + e.message);
    }

    setLoading(false);
  }

  // Export PDF
  async function downloadPDF() {
    const meta = {
      name: "Dataset",
      rows: dataset.length,
      columns: columns.length,
    };

    const summary = answer || "No AI summary yet.";

    const res = await fetch("/api/export", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        summary,
        chartBase64,
        metadata: meta,
        kpis,
      }),
    });

    const blob = await res.blob();
    const url = URL.createObjectURL(blob);

    const a = document.createElement("a");
    a.href = url;
    a.download = "useclevr_report.pdf";
    a.click();
  }

  return (
    <div className="p-8 space-y-12">
      {/* HEADER */}
      <div>
        <h1 className="text-3xl font-bold">AI Insights</h1>
        <p className="text-gray-400">
          UseClevr analyzes your dataset with KPIs & schema intelligence.
        </p>
      </div>

      {/* KPIS */}
      {kpis.length > 0 && (
        <div>
          <h2 className="text-xl font-semibold mb-3">Key Metrics</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {kpis.map((kpi, i) => (
              <KpiCard key={i} kpi={kpi} />
            ))}
          </div>
        </div>
      )}

      {/* SCHEMA */}
      <div>
        <h2 className="text-xl font-semibold mb-3">Dataset Schema</h2>
        <SchemaInspector schema={schema} />
      </div>

      {/* AI QUESTION */}
      <div className="p-6 bg-white/10 dark:bg-[#0B0B12]/30 border rounded-xl backdrop-blur-xl space-y-4">
        <textarea
          rows={3}
          value={question}
          onChange={(e) => setQuestion(e.target.value)}
          className="w-full p-3 rounded-lg bg-black/20 border border-gray-700 text-white"
          placeholder="Ask a question about your data (e.g., 'Which column correlates strongest with Revenue?')"
        />

        <button
          onClick={askAI}
          disabled={loading}
          className="px-6 py-3 bg-gradient-to-r from-purple-600 to-cyan-400 rounded-lg text-white font-medium hover:scale-105 transition disabled:opacity-40"
        >
          {loading ? "Analyzing..." : "Ask AI"}
        </button>
      </div>

      {/* AI RESPONSE */}
      {answer && (
        <div className="p-6 bg-white/10 dark:bg-[#0B0B12]/30 border rounded-xl backdrop-blur-xl">
          <h3 className="font-semibold mb-2">AI Response</h3>
          <p className="whitespace-pre-line text-gray-300">{answer}</p>

          <button
            onClick={downloadPDF}
            className="mt-4 px-5 py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition"
          >
            Download PDF Report
          </button>
        </div>
      )}

      {/* CHART SUGGESTIONS (build-safe) */}
      <ChartSuggestions dataset={dataset} />
    </div>
  );
}
