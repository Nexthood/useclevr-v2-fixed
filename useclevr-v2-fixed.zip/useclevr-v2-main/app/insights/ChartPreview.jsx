"use client";

import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
} from "recharts";

const sampleData = [
  { name: "Mon", value: 400 },
  { name: "Tue", value: 300 },
  { name: "Wed", value: 500 },
  { name: "Thu", value: 200 },
  { name: "Fri", value: 650 },
  { name: "Sat", value: 480 },
  { name: "Sun", value: 700 },
];

export default function ChartPreview() {
  return (
    <div className="p-6 bg-white rounded-xl shadow border h-72">
      <h2 className="text-lg font-semibold mb-3">Weekly Trend</h2>

      <ResponsiveContainer width="100%" height="100%">
        <LineChart data={sampleData}>
          <XAxis dataKey="name" stroke="#888" />
          <YAxis stroke="#888" />
          <Tooltip />
          <Line type="monotone" dataKey="value" stroke="#6366f1" strokeWidth={3} />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
}
