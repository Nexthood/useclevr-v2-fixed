"use client";

import {
  LineChart,
  Line,
  BarChart,
  Bar,
  PieChart,
  Pie,
  Cell,
  Tooltip,
  XAxis,
  YAxis,
  ResponsiveContainer,
} from "recharts";

const COLORS = ["#6366f1", "#10b981", "#f59e0b", "#ef4444"];

export default function AutoChart({ data }) {
  if (!data || data.length === 0) {
    return <p className="text-gray-500">No chartable dataset provided.</p>;
  }

  const sample = data[0];
  const keys = Object.keys(sample);

  // Detect numeric columns
  const numeric = keys.filter((k) => typeof sample[k] === "number");
  const nonNumeric = keys.filter((k) => typeof sample[k] !== "number");

  // PICK WHAT CHART TYPE TO USE:
  // If we have numeric trend → Line chart
  if (numeric.length === 1 && nonNumeric.length === 1) {
    const valueKey = numeric[0];
    const labelKey = nonNumeric[0];

    return (
      <ResponsiveContainer width="100%" height={300}>
        <LineChart data={data}>
          <XAxis dataKey={labelKey} stroke="#555" />
          <YAxis stroke="#555" />
          <Tooltip />
          <Line
            type="monotone"
            dataKey={valueKey}
            stroke="#6366f1"
            strokeWidth={3}
          />
        </LineChart>
      </ResponsiveContainer>
    );
  }

  // If numeric only → Bar chart
  if (numeric.length >= 2) {
    const valueKey = numeric[1];
    const labelKey = numeric[0];

    return (
      <ResponsiveContainer width="100%" height={300}>
        <BarChart data={data}>
          <XAxis dataKey={labelKey} stroke="#555" />
          <YAxis stroke="#555" />
          <Tooltip />
          <Bar dataKey={valueKey} fill="#6366f1" />
        </BarChart>
      </ResponsiveContainer>
    );
  }

  // If categorical and small → Pie chart
  if (nonNumeric.length >= 1 && data.length <= 6) {
    const pieKey = numeric.length > 0 ? numeric[0] : keys[1];
    const labelKey = nonNumeric[0];

    return (
      <ResponsiveContainer width="100%" height={300}>
        <PieChart>
          <Pie
            data={data}
            dataKey={pieKey}
            nameKey={labelKey}
            outerRadius={100}
            fill="#8884d8"
            label
          >
            {data.map((entry, i) => (
              <Cell key={i} fill={COLORS[i % COLORS.length]} />
            ))}
          </Pie>
        </PieChart>
      </ResponsiveContainer>
    );
  }

  // Fallback
  return (
    <p className="text-gray-500">
      Unable to auto-detect visualization for this dataset.
    </p>
  );
}
