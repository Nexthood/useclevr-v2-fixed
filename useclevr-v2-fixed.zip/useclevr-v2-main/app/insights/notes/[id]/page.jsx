"use client";

import { useParams } from "next/navigation";
import { useState, useEffect } from "react";
import Link from "next/link";

export default function NoteDetailPage() {
  const { id } = useParams();
  const [note, setNote] = useState(null);

  useEffect(() => {
    const stored = localStorage.getItem("useclevr_insights_notes");
    if (!stored) return;

    const notes = JSON.parse(stored);
    const found = notes.find((n) => String(n.id) === id);

    setNote(found);
  }, [id]);

  if (!note) {
    return (
      <div className="p-10">
        <p className="text-gray-500">Insight not found.</p>
      </div>
    );
  }

  return (
    <div className="p-10 space-y-6">
      <Link
        href="/insights/notes"
        className="px-4 py-2 bg-gray-700 text-white rounded-lg"
      >
        ← Back
      </Link>

      <h1 className="text-3xl font-bold">{note.title}</h1>
      <p className="text-gray-500">{note.date}</p>

      <div className="p-6 bg-white dark:bg-neutral-900 border rounded-xl dark:border-gray-700">
        <pre className="whitespace-pre-wrap text-sm text-gray-800 dark:text-gray-200">
          {note.text}
        </pre>
      </div>
    </div>
  );
}
