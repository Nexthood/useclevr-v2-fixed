"use client";

export default function DatasetsPage() {
  return (
    <div className="p-8">
      <h1 className="text-2xl font-bold">Datasets</h1>
      <p className="text-gray-400">
        Dataset management will be re-enabled later.
      </p>
    </div>
  );
}
