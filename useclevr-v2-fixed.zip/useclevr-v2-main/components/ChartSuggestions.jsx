export default function ChartSuggestions() {
  return null;
}
