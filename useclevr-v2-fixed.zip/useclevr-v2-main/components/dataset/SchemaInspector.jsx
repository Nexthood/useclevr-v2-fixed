"use client";

export default function SchemaInspector({ data = [] }) {
  if (!data || data.length === 0) {
    return (
      <p className="text-gray-500">
        No schema detected. Upload a dataset first.
      </p>
    );
  }

  return (
    <div className="space-y-4">
      {data.map((col, i) => (
        <div
          key={i}
          className="p-4 bg-white dark:bg-neutral-900 border dark:border-gray-800 rounded-xl shadow-sm"
        >
          <h3 className="text-lg font-semibold mb-2">{col.column}</h3>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">

            {/* Type */}
            <div>
              <p className="text-gray-500">Type</p>
              <p className="font-medium">{col.type}</p>
            </div>

            {/* Missing */}
            <div>
              <p className="text-gray-500">Missing %</p>
              <p className="font-medium">{col.emptyPercentage.toFixed(1)}%</p>
            </div>

            {/* Sample */}
            <div>
              <p className="text-gray-500">Sample</p>
              <p className="font-medium break-all">
                {col.sample || "—"}
              </p>
            </div>

            {/* Optional stats */}
            {col.stats ? (
              <div>
                <p className="text-gray-500">Range</p>
                <p className="font-medium">
                  {col.stats.min} → {col.stats.max}
                </p>
              </div>
            ) : (
              <div>
                <p className="text-gray-500">Range</p>
                <p className="font-medium">n/a</p>
              </div>
            )}

          </div>
        </div>
      ))}
    </div>
  );
}
