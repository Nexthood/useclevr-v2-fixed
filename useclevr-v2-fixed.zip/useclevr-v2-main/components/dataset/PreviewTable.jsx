"use client";

export default function PreviewTable({ dataset }) {
  if (!dataset || dataset.length === 0) {
    return (
      <div className="text-gray-500 text-sm">
        No dataset loaded.
      </div>
    );
  }

  const columns = Object.keys(dataset[0]);
  const previewRows = dataset.slice(0, 20); // show first 20 rows

  return (
    <div className="p-6 bg-white rounded-xl shadow space-y-4">
      <h2 className="text-xl font-semibold">Dataset Preview</h2>

      <div className="overflow-auto border rounded-xl">
        <table className="w-full text-sm border-collapse">
          <thead>
            <tr className="bg-gray-50 border-b">
              {columns.map((col, i) => (
                <th
                  key={i}
                  className="text-left py-2 px-3 font-semibold text-gray-600"
                >
                  {col}
                </th>
              ))}
            </tr>
          </thead>

          <tbody>
            {previewRows.map((row, rIndex) => (
              <tr
                key={rIndex}
                className="border-b hover:bg-gray-50 text-gray-700"
              >
                {columns.map((col, cIndex) => (
                  <td key={cIndex} className="py-2 px-3">
                    {String(row[col])}
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
