export default function CompareChart() {
  return null;
}
